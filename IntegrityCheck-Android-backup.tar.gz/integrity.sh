#!/data/data/com.termux/files/usr/bin/bash

clear

echo "========================================="
echo "      INTEGRITY CHECK ANDROID"
echo "           TERMUX EDITION"
echo "========================================="
echo

while true
do
    echo "============== MENU =============="
    echo
    echo "[00] OLHO DE DEUS 😉📂"
    echo "[01] Executar Tudo"
    echo
    echo "[02] Sistema"
    echo "[03] USB"
    echo "[04] Root"
    echo "[05] ADB"
    echo "[06] VPN"
    echo "[07] Apps"
    echo "[08] Armazenamento"
    echo "[09] Processos"
    echo "[10] Segurança"
    echo "[11] Suspeitos"
    echo "[12] Bateria"
    echo "[13] RAM"
    echo "[14] Rede"
    echo "[15] Relatório"
    echo "[16] Rede Avançada"
    echo "[17] Wi-Fi"
    echo "[18] Sensores"
    echo "[19] CPU"
    echo "[20] Armazenamento Avançado"
    echo "[21] Segurança Sistema"
    echo "[22] Wi-Fi Avançado"
    echo "[23] Bluetooth"
    echo "[24] USB Avançado"
    echo "[25] Jogos Suspeitos"
    echo "[26] Apps de Risco"
    echo "[27] Integridade"
    echo "[28] Relatório Premium"
    echo "[29] Resumo"
    echo "[30] Tela"
    echo "[31] Câmera"
    echo "[32] Áudio"
    echo "[33] Sensores Avançados"
    echo "[34] Conectividade"
    echo "[35] Relatório Técnico"
    echo "[36] Diagnóstico"
    echo "[37] Pontuação"
    echo "[38] Exportar Relatório"
    echo
    echo "[0] Sair"
    echo
    read -p "Escolha uma opção: " op

    case $op in

    00)
        bash modulos/mod00_olho_de_deus.sh
        ;;

    01)
        for arq in modulos/*.sh
        do
            bash "$arq"
            echo
        done
        ;;

    02) bash modulos/mod01_sistema.sh ;;
    03) bash modulos/mod01_usb.sh ;;
    04) bash modulos/mod02_root.sh ;;
    05) bash modulos/mod03_adb.sh ;;
    06) bash modulos/mod04_vpn.sh ;;
    07) bash modulos/mod05_apps.sh ;;
    08) bash modulos/mod06_armazenamento.sh ;;
    09) bash modulos/mod07_processos.sh ;;
    10) bash modulos/mod08_seguranca.sh ;;
    11) bash modulos/mod09_suspeitos.sh ;;
    12) bash modulos/mod11_bateria.sh ;;
    13) bash modulos/mod12_ram.sh ;;
    14) bash modulos/mod13_rede.sh ;;
    15) bash modulos/mod14_relatorio.sh ;;
    16) bash modulos/mod15_rede_avancada.sh ;;
    17) bash modulos/mod16_wifi.sh ;;
    18) bash modulos/mod17_sensores.sh ;;
    19) bash modulos/mod18_cpu.sh ;;
    20) bash modulos/mod19_armazenamento_avancado.sh ;;
    21) bash modulos/mod20_seguranca_sistema.sh ;;
    22) bash modulos/mod22_wifi.sh ;;
    23) bash modulos/mod23_bluetooth.sh ;;
    24) bash modulos/mod24_usb_avancado.sh ;;
    25) bash modulos/mod25_jogos_suspeitos.sh ;;
    26) bash modulos/mod26_apps_risco.sh ;;
    27) bash modulos/mod27_integridade.sh ;;
    28) bash modulos/mod28_relatorio_premium.sh ;;
    29) bash modulos/mod29_resumo.sh ;;
    30) bash modulos/mod31_tela.sh ;;
    31) bash modulos/mod32_camera.sh ;;
    32) bash modulos/mod33_audio.sh ;;
    33) bash modulos/mod34_sensores_avancados.sh ;;
    34) bash modulos/mod35_conectividade.sh ;;
    35) bash modulos/mod36_relatorio_tecnico.sh ;;
    36) bash modulos/mod37_diagnostico.sh ;;
    37) bash modulos/mod38_pontuacao.sh ;;
    38) bash modulos/mod39_exportar_relatorio.sh ;;

    0)
        echo "Saindo..."
        exit
        ;;

    *)
        echo "Opção inválida."
        ;;
    esac

    echo
    read -p "Pressione ENTER para continuar..."
    clear
done
